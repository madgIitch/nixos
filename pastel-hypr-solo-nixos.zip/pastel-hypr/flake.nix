{
  description = "pastel-hypr — Hyprland con scroll infinito y estética pastel, para el ROG Strix G15 G513IC";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    home-manager = {
      url = "github:nix-community/home-manager";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    nixos-hardware = {
      url = "github:NixOS/nixos-hardware";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, home-manager, ... }@inputs: {
    # Preset reutilizable en cualquier máquina
    nixosModules.default = import ./modules/nixos.nix;
    homeManagerModules.default = import ./modules/home;

    # Tu portátil: ASUS ROG Strix G15 G513IC
    nixosConfigurations.strix = nixpkgs.lib.nixosSystem {
      specialArgs = { inherit inputs; };
      modules = [
        ./hosts/strix
        self.nixosModules.default
        home-manager.nixosModules.home-manager
        {
          home-manager = {
            useGlobalPkgs = true;
            useUserPackages = true;
            backupFileExtension = "bak";
            users.pepe.imports = [
              self.homeManagerModules.default
              ./hosts/strix/home.nix
            ];
          };
        }
      ];
    };
  };
}
