# pastel-hypr · ROG Strix G15 (G513IC)

NixOS + Home Manager con Hyprland 0.57: columnas con scroll infinito, fondo negro,
bordes en degradado rosa → lila → azul, barra rosa abajo y apps en tema claro.
Inspirado en el setup de @XMihura.

**Equipo:** Ryzen 7 4800H + Radeon integrada · RTX 3050 Laptop · 16 GB · NVMe Intel 512 GB ·
Wi-Fi/BT MediaTek MT7921 · 1920×1080 a 144 Hz · teclado español.
**Instalación:** dual boot junto a Windows 11.

```
flake.nix / flake.lock      versiones fijadas (nixos-unstable 2026-11-21)
modules/                    el preset visual (reutilizable en cualquier máquina)
hosts/strix/
  default.nix               GRUB dual boot, idioma, usuario, Nix, Docker
  hardware.nix              perfil g513im de nixos-hardware + NVIDIA PRIME, asusd, zram
  hardware-configuration.nix  discos por etiqueta (NIXOS y la EFI de Windows como ESP)
  home.nix                  ajustes de Hyprland del portátil + herramientas de desarrollo
```

## Cómo queda el disco

| Partición | Qué es | Cambio |
|---|---|---|
| p1 · 100 MB | EFI de Windows | se comparte; se le pone la etiqueta `ESP` |
| p2 · 16 MB | Reservada de Windows | nada |
| p3 · C: | Windows | se encoge ~60 GB |
| p4 · 800 MB | Recuperación de Windows | nada |
| **nueva · ~60 GB** | **NixOS (ext4, `NIXOS`)** | se crea en el hueco |

Los kernels de NixOS van dentro de la partición NIXOS (en `/boot`), no en la EFI,
porque en 100 MB no caben. Por eso se usa GRUB, que además pone Windows en el menú.

## 1. En Windows

1. **Copia de seguridad** de lo importante. Encoger C: es seguro, pero mejor tener copia.
2. **Apaga el inicio rápido y la hibernación.** En PowerShell como administrador:
   ```powershell
   powercfg /h off
   ```
   Sin esto, Windows deja C: "a medias" y Linux no puede leerla.
3. **Encoge C:** `Win + X` → *Administración de discos* → clic derecho en C: → *Reducir volumen* →
   `61440` MB (60 GB). Deja el espacio como *No asignado*; no crees nada.
   Si Windows ofrece menos, acepta lo que ofrezca (mínimo ~40 GB).
4. **Pasa esta carpeta a C:**: descomprime el zip en `C:\pastel-hypr` (tiene que quedar
   `C:\pastel-hypr\flake.nix`).
5. **Graba la ISO** *minimal* de NixOS (unstable, x86_64) en el USB SanDisk con
   [Rufus](https://rufus.ie) (GPT, UEFI). Esto borra el USB.

Secure Boot y BitLocker ya están desactivados en tu equipo, así que no hay que tocar la BIOS.

## 2. En el instalador de NixOS

Arranca desde el USB (pulsa `Esc` al encender → elige el USB).

```bash
sudo -i
loadkeys es
nmtui                                  # conecta al Wi-Fi

lsblk -f                               # comprueba: nvme0n1p1 vfat 100M, nvme0n1p3 ntfs (C:)

# Partición nueva en el hueco libre (ocupa todo el espacio no asignado)
sgdisk -n 0:0:0 -t 0:8300 -c 0:NIXOS /dev/nvme0n1
partprobe && sleep 2
mkfs.ext4 -L NIXOS /dev/disk/by-partlabel/NIXOS
fatlabel /dev/nvme0n1p1 ESP            # etiqueta la EFI de Windows (no le afecta)

mount /dev/disk/by-label/NIXOS /mnt
mount --mkdir /dev/disk/by-label/ESP /mnt/boot/efi

# Copia la configuración desde C:
mount --mkdir -t ntfs3 -o ro /dev/nvme0n1p3 /win
mkdir -p /mnt/etc/nixos && cp -r /win/pastel-hypr/. /mnt/etc/nixos/
umount /win

# Comprueba los IDs de las gráficas: deben salir 05:00.0 (AMD) y 01:00.0 (NVIDIA)
lspci -D | grep -E "VGA|3D"

nixos-install --flake /mnt/etc/nixos#strix
reboot
```

Si `lspci` muestra otros números, cámbialos en `hosts/strix/hardware.nix`
(variables del principio y `hardware.nvidia.prime.*BusId`) antes de `nixos-install`.

## 3. Primer arranque

- Sale el menú de GRUB con **NixOS** y **Windows Boot Manager**. Recuerda el último que elegiste.
  Si un día arranca directo en Windows (a veces pasa tras una actualización), pon *NixOS*
  primero en la BIOS (`F2` → Boot).
- Entra como `pepe` con la contraseña `cambiame` y cámbiala con `passwd`.
- Copia la configuración a tu carpeta: `cp -r /etc/nixos ~/pastel-hypr`.
  Si la metes en git, haz `git add` de los archivos nuevos: los flakes ignoran lo que no esté añadido.
- A partir de ahí: `rebuild` aplica cambios y `update` actualiza versiones y reconstruye.
- Tu disco C: está en `/mnt/windows`, solo lectura.

## Migrar del todo a NixOS más adelante

Cuando quieras quitar Windows: arranca el USB, borra p2–p4, amplía NIXOS a todo el disco
(`growpart` + `resize2fs`) y quita `useOSProber` y el montaje de `/mnt/windows`.
La EFI se queda como está.

## Lo específico del portátil

- **Gráficas:** Hyprland dibuja con la Radeon y la RTX 3050 va apagada.
  Para usarla en un programa: `nvidia-offload programa`.
  El HDMI suele ir cableado a la NVIDIA, así que también vale para pantalla externa.
- **Batería:** carga hasta el 80 %. Para llegar al 100 % una vez: `charge-upto 100`.
- **ASUS:** `asusctl` controla la luz del teclado, los ventiladores y los perfiles de energía.
- **Hora:** el reloj del BIOS va en hora local, como en Windows, para que no se desfase al cambiar.
- **Espacio:** con ~60 GB, Nix limpia cada semana lo que tenga más de 7 días.
  Si te falta espacio: `sudo nix-collect-garbage -d` y `docker system prune`.
- **Memoria:** 16 GB + zram (swap comprimida en RAM).

## Herramientas incluidas

Node 22, pnpm, Bun, Deno, Supabase CLI (con Docker bajo demanda), adb, uv/Python,
gh, lazygit, VS Code, Claude Code, Codex, direnv + nix-direnv, zsh + starship.

## Atajos

| Tecla | Acción |
|---|---|
| `Super + Enter` | Terminal (foot) |
| `Super + Espacio` | Lanzador (fuzzel) |
| `Super + B` / `E` | Chrome / Nautilus |
| `Super + ← →` | Moverse por las columnas |
| `Super + rueda` · 3 dedos ↔ | Desplazar las columnas (scroll infinito) |
| `Super + Shift + ← →` | Intercambiar columnas |
| `Super + [` / `]` | Meter/sacar la ventana de la columna vecina |
| `Super + R` / `Shift + R` | Cambiar el ancho de la columna |
| `Super + C` | Encajar la columna activa |
| `Super + 1..9` · 3 dedos ↕ | Workspaces |
| `Super + L` | Bloquear |
| `Super + Q` | Cerrar ventana |

## Notas

- Hyprland ≥ 0.57 se configura en Lua (`~/.config/hypr/hyprland.lua`) y trae el layout
  `scrolling` de serie. `hyprctl dispatch` también recibe Lua:
  `hyprctl dispatch 'hl.dsp.layout("fit active")'`.
- Waybar, mako, hypridle y nm-applet son servicios de systemd de usuario (los arranca UWSM).
- Los colores están en `modules/palette.nix`.
