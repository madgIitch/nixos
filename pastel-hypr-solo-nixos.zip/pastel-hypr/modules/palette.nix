# Paleta única del preset: cambia aquí y se propaga a todo
{
  black    = "000000";
  bg       = "f7f7f9"; # fondo apps claras
  surface  = "ececf1";
  text     = "2b2b33";
  subtext  = "8a8a96";

  pink     = "f2a7c3"; # borde activo / barra
  pinkDeep = "d9679f"; # workspace activo
  barPink  = "efc6d6"; # fondo de la barra
  lilac    = "c4b5f4";
  sky      = "a9d4ea";
  lock     = "78bccc"; # pastel cyan-blue del lockscreen
  idle     = "cfd8e3"; # borde inactivo

  font     = "Inter";
  monoFont = "JetBrainsMono Nerd Font";
}
