{ pkgs, ... }:
{
  imports = [
    ./hyprland.nix
    ./waybar.nix
    ./lock.nix
    ./theme.nix
    ./apps.nix
  ];

  # Applet de red como servicio systemd de usuario
  services.network-manager-applet.enable = true;

  home.packages = with pkgs; [
    brightnessctl
    playerctl
    pavucontrol
    grim
    slurp
    wl-clipboard
    nautilus
    google-chrome
  ];
}
