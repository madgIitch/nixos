{ ... }:
let
  c = import ../palette.nix;
  dpms = state: "hyprctl dispatch 'hl.dsp.dpms({ action = \"${state}\" })'";
in
{
  # Lockscreen en pastel cyan-blue (#78BCCC), como en el vídeo
  programs.hyprlock = {
    enable = true;
    settings = {
      general = { hide_cursor = true; grace = 0; };

      background = [{ color = "rgb(${c.lock})"; }];

      label = [
        {
          text = "$TIME";
          font_family = c.font;
          font_size = 96;
          color = "rgba(ffffffee)";
          position = "0, 160";
          halign = "center";
          valign = "center";
        }
        {
          text = "cmd[update:60000] date +'%A %d %B'";
          font_family = c.font;
          font_size = 18;
          color = "rgba(ffffffcc)";
          position = "0, 70";
          halign = "center";
          valign = "center";
        }
      ];

      input-field = [{
        size = "280, 48";
        rounding = 24;
        outline_thickness = 2;
        outer_color = "rgb(ffffff)";
        inner_color = "rgba(ffffff40)";
        font_color = "rgb(ffffff)";
        check_color = "rgb(${c.lilac})";
        fail_color = "rgb(${c.pinkDeep})";
        placeholder_text = "contraseña";
        fade_on_empty = false;
        dots_center = true;
        position = "0, -40";
        halign = "center";
        valign = "center";
      }];
    };
  };

  services.hypridle = {
    enable = true;
    settings = {
      general = {
        lock_cmd = "pidof hyprlock || hyprlock";
        before_sleep_cmd = "loginctl lock-session";
        after_sleep_cmd = dpms "on";
      };
      listener = [
        { timeout = 300; on-timeout = "loginctl lock-session"; }
        { timeout = 420; on-timeout = dpms "off"; on-resume = dpms "on"; }
      ];
    };
  };
}
