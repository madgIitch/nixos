{ ... }:
let
  c = import ../palette.nix;
in
{
  wayland.windowManager.hyprland = {
    enable = true;
    # Usa el Hyprland del módulo NixOS (programs.hyprland)
    package = null;
    portalPackage = null;
    systemd.enable = false; # lo gestiona UWSM

    # Hyprland ≥ 0.57 se configura en Lua (hypr/hyprland.lua).
    # El layout "scrolling" (scroll infinito de columnas) viene de serie: sin plugins.
    configType = "lua";

    extraConfig = ''
      local mod      = "SUPER"
      local terminal = "foot"
      local menu     = "fuzzel"
      local browser  = "google-chrome-stable"

      hl.monitor({ output = "", mode = "preferred", position = "auto", scale = "auto" })

      ----------------------------------------------------------------
      -- Aspecto: fondo negro, bordes degradado rosa → lila → azul
      ----------------------------------------------------------------
      hl.config({
        general = {
          layout           = "scrolling",
          gaps_in          = 3,
          gaps_out         = 4,
          border_size      = 2,
          resize_on_border = true,
          col = {
            active_border   = { colors = { "rgb(${c.pink})", "rgb(${c.lilac})", "rgb(${c.sky})" }, angle = 45 },
            inactive_border = "rgba(${c.idle}cc)",
          },
        },

        decoration = {
          rounding       = 12,
          rounding_power = 2,
          shadow = { enabled = true, range = 12, render_power = 3, color = 0x33000000 },
          blur   = { enabled = false }, -- fondo negro liso: el blur no aporta
        },

        -- Scroll infinito: columnas que se desplazan en horizontal (estilo niri/PaperWM)
        scrolling = {
          column_width             = 0.6, -- ~2 columnas visibles (X + Codex, como en el vídeo)
          explicit_column_widths   = "0.333, 0.5, 0.6, 0.667, 1.0",
          fullscreen_on_one_column = true,
          focus_fit_method         = 1,   -- al enfocar, encaja la columna en pantalla
          follow_focus             = true,
          wrap_focus               = false,
        },

        misc = {
          disable_hyprland_logo    = true,
          disable_splash_rendering = true,
          force_default_wallpaper  = 0,
          background_color         = 0xff${c.black}, -- sin proceso de wallpaper
        },

        input = {
          kb_layout    = "es",
          follow_mouse = 1,
          touchpad     = { natural_scroll = true, scroll_factor = 0.6 },
        },

        animations = { enabled = true },
      })

      hl.curve("smooth", { type = "bezier", points = { {0.22, 1}, {0.36, 1} } })
      hl.curve("easy",   { type = "spring", mass = 1, stiffness = 238.1191, damping = 24.21279333 })

      hl.animation({ leaf = "windows",     enabled = true, speed = 4.5, spring = "easy" })
      hl.animation({ leaf = "windowsIn",   enabled = true, speed = 4,   spring = "easy", style = "popin 90%" })
      hl.animation({ leaf = "border",      enabled = true, speed = 6,   bezier = "smooth" })
      hl.animation({ leaf = "borderangle", enabled = true, speed = 40,  bezier = "smooth", style = "loop" }) -- degradado girando lento
      hl.animation({ leaf = "fade",        enabled = true, speed = 4,   bezier = "smooth" })
      hl.animation({ leaf = "layers",      enabled = true, speed = 3,   bezier = "smooth", style = "fade" })
      hl.animation({ leaf = "workspaces",  enabled = true, speed = 4,   bezier = "smooth", style = "slidevert" })

      -- Autoarranque: waybar, mako, hypridle y nm-applet son servicios systemd de usuario
      -- (los arranca UWSM con graphical-session.target), así no se lanzan dos veces.

      ----------------------------------------------------------------
      -- Atajos
      ----------------------------------------------------------------
      hl.bind(mod .. " + Return", hl.dsp.exec_cmd("uwsm app -- " .. terminal))
      hl.bind(mod .. " + space",  hl.dsp.exec_cmd(menu))
      hl.bind(mod .. " + B",      hl.dsp.exec_cmd("uwsm app -- " .. browser))
      hl.bind(mod .. " + E",      hl.dsp.exec_cmd("uwsm app -- nautilus"))
      hl.bind(mod .. " + Q",      hl.dsp.window.close())
      hl.bind(mod .. " + F",      hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }))
      hl.bind(mod .. " + SHIFT + F", hl.dsp.window.float({ action = "toggle" }))
      hl.bind(mod .. " + L",      hl.dsp.exec_cmd("hyprlock"))
      hl.bind("Print",            hl.dsp.exec_cmd([[grim -g "$(slurp)" - | wl-copy]]))

      -- Cinta de columnas
      hl.bind(mod .. " + left",   hl.dsp.layout("focus l"))
      hl.bind(mod .. " + right",  hl.dsp.layout("focus r"))
      hl.bind(mod .. " + up",     hl.dsp.layout("focus u"))
      hl.bind(mod .. " + down",   hl.dsp.layout("focus d"))
      hl.bind(mod .. " + period", hl.dsp.layout("move +col"))
      hl.bind(mod .. " + comma",  hl.dsp.layout("move -col"))

      -- Mover ventanas / columnas
      hl.bind(mod .. " + SHIFT + left",  hl.dsp.layout("swapcol l"))
      hl.bind(mod .. " + SHIFT + right", hl.dsp.layout("swapcol r"))
      hl.bind(mod .. " + SHIFT + up",    hl.dsp.window.move({ direction = "up" }))
      hl.bind(mod .. " + SHIFT + down",  hl.dsp.window.move({ direction = "down" }))
      hl.bind(mod .. " + bracketleft",   hl.dsp.layout("consume_or_expel prev"))
      hl.bind(mod .. " + bracketright",  hl.dsp.layout("consume_or_expel next"))

      -- Ancho de columna
      hl.bind(mod .. " + R",         hl.dsp.layout("colresize +conf"))
      hl.bind(mod .. " + SHIFT + R", hl.dsp.layout("colresize -conf"))
      hl.bind(mod .. " + C",         hl.dsp.layout("fit active"))
      hl.bind(mod .. " + SHIFT + C", hl.dsp.layout("center"))

      -- Super + rueda: desplaza la cinta (el "infinite scroll")
      hl.bind(mod .. " + mouse_down", hl.dsp.layout("move +col"))
      hl.bind(mod .. " + mouse_up",   hl.dsp.layout("move -col"))

      -- Trackpad: 3 dedos horizontal mueve la cinta, vertical cambia de workspace
      hl.gesture({ fingers = 3, direction = "horizontal", action = "scroll_move" })
      hl.gesture({ fingers = 3, direction = "vertical",   action = "workspace" })

      -- Workspaces
      for i = 1, 9 do
        hl.bind(mod .. " + " .. i,         hl.dsp.focus({ workspace = i }))
        hl.bind(mod .. " + SHIFT + " .. i, hl.dsp.window.move({ workspace = i }))
      end

      -- Ratón
      hl.bind(mod .. " + mouse:272", hl.dsp.window.drag(),   { mouse = true })
      hl.bind(mod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true })

      -- Teclas multimedia
      hl.bind("XF86AudioRaiseVolume",  hl.dsp.exec_cmd("wpctl set-volume -l 1 @DEFAULT_AUDIO_SINK@ 5%+"), { locked = true, repeating = true })
      hl.bind("XF86AudioLowerVolume",  hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"),      { locked = true, repeating = true })
      hl.bind("XF86AudioMute",         hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"),     { locked = true })
      hl.bind("XF86MonBrightnessUp",   hl.dsp.exec_cmd("brightnessctl -e4 -n2 set 5%+"),                  { locked = true, repeating = true })
      hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl -e4 -n2 set 5%-"),                  { locked = true, repeating = true })
      hl.bind("XF86AudioPlay",         hl.dsp.exec_cmd("playerctl play-pause"),                           { locked = true })

      ----------------------------------------------------------------
      -- Reglas
      ----------------------------------------------------------------
      hl.window_rule({
        name  = "flotantes",
        match = { class = "^(pavucontrol|nm-connection-editor|blueman-manager|org.pulseaudio.pavucontrol)$" },
        float = true,
        size  = "720 480",
      })
      hl.window_rule({ name = "no-maximize", match = { class = ".*" }, suppress_event = "maximize" })
    '';
  };
}
