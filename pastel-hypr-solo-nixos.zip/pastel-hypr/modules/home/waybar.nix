{ ... }:
let
  c = import ../palette.nix;
in
{
  programs.waybar = {
    enable = true;
    systemd.enable = true; # servicio de usuario, no exec desde Hyprland
    settings.main = {
      layer = "top";
      position = "bottom";
      height = 30;
      margin-left = 4;
      margin-right = 4;
      margin-bottom = 4;
      spacing = 6;

      modules-left = [ "hyprland/workspaces" "cpu" "memory" ];
      modules-center = [ "wlr/taskbar" ];
      modules-right = [
        "pulseaudio" "network" "hyprland/language" "tray" "clock" "custom/lock"
      ];

      "hyprland/workspaces" = {
        format = "{id}";
        persistent-workspaces."*" = 3;
        on-scroll-up = "hyprctl dispatch 'hl.dsp.focus({ workspace = \"e-1\" })'";
        on-scroll-down = "hyprctl dispatch 'hl.dsp.focus({ workspace = \"e+1\" })'";
      };

      cpu = { format = "󰍛 {usage}%"; interval = 3; };
      memory = { format = "󰘚 {used:0.1f}G"; interval = 5; };

      # "Dock" central: iconos de las apps abiertas
      "wlr/taskbar" = {
        format = "{icon}";
        icon-size = 18;
        on-click = "activate";
        on-click-middle = "close";
        ignore-list = [ ];
      };

      pulseaudio = {
        format = "{icon} {volume}%";
        format-muted = "󰝟";
        format-icons.default = [ "󰕿" "󰖀" "󰕾" ];
        on-click = "pavucontrol";
      };
      network = {
        format-wifi = "󰖩";
        format-ethernet = "󰈀";
        format-disconnected = "󰖪";
        tooltip-format = "{essid} {signalStrength}%";
      };
      "hyprland/language" = { format = "{short}"; format-es = "es"; };
      tray = { icon-size = 15; spacing = 8; };
      clock = {
        format = "{:%a %d %b  %H:%M}";
        tooltip-format = "<tt>{calendar}</tt>";
      };
      "custom/lock" = {
        format = "󰌾";
        on-click = "hyprlock";
        tooltip = false;
      };
    };

    style = ''
      * {
        font-family: "${c.font}", "${c.monoFont}";
        font-size: 12px;
        min-height: 0;
        border: none;
      }

      window#waybar {
        background: #${c.barPink};
        border-radius: 12px;
        color: #${c.text};
      }

      .modules-left, .modules-right { padding: 0 8px; }

      #workspaces button {
        padding: 0;
        margin: 4px 2px;
        min-width: 20px;
        border-radius: 999px;
        color: #${c.subtext};
        background: transparent;
      }
      #workspaces button.active {
        background: #${c.pinkDeep};
        color: #ffffff;
      }
      #workspaces button:hover { background: alpha(#${c.pinkDeep}, 0.25); }

      #cpu, #memory { color: #6b7bd6; padding: 0 4px; }

      #taskbar {
        background: alpha(#ffffff, 0.45);
        border-radius: 10px;
        margin: 4px 0;
        padding: 0 6px;
      }
      #taskbar button { padding: 0 4px; border-radius: 8px; }
      #taskbar button.active { background: alpha(#${c.lilac}, 0.6); }

      #pulseaudio, #network, #language, #tray, #clock { padding: 0 5px; color: #${c.text}; }
      #language { text-transform: lowercase; }

      #custom-lock {
        color: #${c.lilac};
        font-size: 14px;
        padding: 0 6px 0 4px;
      }

      tooltip {
        background: #${c.bg};
        border: 1px solid #${c.lilac};
        border-radius: 10px;
        color: #${c.text};
      }
    '';
  };
}
