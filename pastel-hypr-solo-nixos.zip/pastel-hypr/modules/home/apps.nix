{ ... }:
let
  c = import ../palette.nix;
in
{
  # Terminal claro con acentos pastel
  programs.foot = {
    enable = true;
    settings = {
      main = { font = "${c.monoFont}:size=11"; pad = "12x10"; };
      colors = {
        background = c.bg;
        foreground = c.text;
        regular0 = "3b3b45"; regular1 = "d9679f"; regular2 = "6fb99a"; regular3 = "d6a35c";
        regular4 = "6b7bd6"; regular5 = "a58be0"; regular6 = c.lock;    regular7 = "c9c9d3";
        bright0  = "8a8a96"; bright1  = "f2a7c3"; bright2  = "9ad3b8"; bright3  = "ecc68f";
        bright4  = "9aa6ec"; bright5  = c.lilac;  bright6  = c.sky;     bright7  = "ffffff";
        selection-background = c.lilac;
        selection-foreground = c.text;
      };
    };
  };

  # Lanzador
  programs.fuzzel = {
    enable = true;
    settings = {
      main = {
        font = "${c.font}:size=12";
        terminal = "foot";
        width = 36;
        lines = 10;
        horizontal-pad = 16;
        vertical-pad = 12;
        icon-theme = "Papirus-Light";
      };
      colors = {
        background = "${c.bg}f2";
        text = "${c.text}ff";
        match = "${c.pinkDeep}ff";
        selection = "${c.lilac}ff";
        selection-text = "${c.text}ff";
        selection-match = "${c.pinkDeep}ff";
        border = "${c.pink}ff";
      };
      border = { width = 2; radius = 12; };
    };
  };

  # Notificaciones
  services.mako = {
    enable = true;
    settings = {
      font = "${c.font} 11";
      background-color = "#${c.bg}";
      text-color = "#${c.text}";
      border-color = "#${c.pink}";
      border-size = 2;
      border-radius = 12;
      padding = "12";
      margin = "8";
      anchor = "top-right";
      default-timeout = 5000;
    };
  };
}
