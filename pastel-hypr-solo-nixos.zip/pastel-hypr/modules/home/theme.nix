{ config, pkgs, ... }:
let
  c = import ../palette.nix;
in
{
  # Apps en claro (X, Codex/Electron, Nautilus… como en el vídeo)
  gtk = {
    enable = true;
    theme = { name = "adw-gtk3"; package = pkgs.adw-gtk3; };
    iconTheme = { name = "Papirus-Light"; package = pkgs.papirus-icon-theme; };
    font = { name = c.font; size = 11; };
    gtk4.theme = config.gtk.theme;
  };

  dconf.settings."org/gnome/desktop/interface" = {
    color-scheme = "prefer-light";
    gtk-theme = "adw-gtk3";
  };

  qt = {
    enable = true;
    platformTheme.name = "adwaita";
    style.name = "adwaita";
  };

  home.pointerCursor = {
    enable = true;
    name = "Bibata-Modern-Classic";
    package = pkgs.bibata-cursors;
    size = 22;
    gtk.enable = true;
    hyprcursor.enable = true;
  };
}
