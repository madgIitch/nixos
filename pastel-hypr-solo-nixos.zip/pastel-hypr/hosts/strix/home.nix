{ pkgs, lib, ... }:
{
  # Ajustes de Hyprland específicos de este portátil (se añaden al preset)
  wayland.windowManager.hyprland.extraConfig = lib.mkMerge [
    (lib.mkBefore ''
      -- Renderizar en la Radeon integrada; la NVIDIA queda como secundaria (HDMI)
      hl.env("AQ_DRM_DEVICES", "/dev/dri/amd-igpu:/dev/dri/nvidia-dgpu")
    '')
    (lib.mkAfter ''
      -- Portátil: pantalla interna a su máxima frecuencia (144 Hz)
      hl.monitor({ output = "eDP-1", mode = "highrr", position = "0x0", scale = 1 })
    '')
  ];

  # ── Herramientas de desarrollo (React Native/Expo, Supabase, Deno, agentes) ──
  home.packages = with pkgs; [
    nodejs_22
    pnpm
    bun
    deno
    supabase-cli
    uv
    python3
    gh
    lazygit
    jq
    ripgrep
    fd
    vscode-fhs
    claude-code
    codex
  ];

  programs.git = {
    enable = true;
    settings = {
      user.name = "José Ortiz Roldán";
      init.defaultBranch = "main";
      pull.rebase = true;
    };
  };

  programs.direnv = {
    enable = true;
    nix-direnv.enable = true; # `use flake` por proyecto
  };

  programs.zsh = {
    enable = true;
    autosuggestion.enable = true;
    syntaxHighlighting.enable = true;
    shellAliases = {
      rebuild = "sudo nixos-rebuild switch --flake ~/pastel-hypr#strix";
      update = "nix flake update --flake ~/pastel-hypr && rebuild";
    };
  };
  programs.starship.enable = true;

  home.stateVersion = "26.05";
}
