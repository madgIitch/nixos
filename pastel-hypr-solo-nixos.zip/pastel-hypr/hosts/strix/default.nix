{ pkgs, ... }:
{
  imports = [
    ./hardware-configuration.nix
    ./hardware.nix
  ];

  # ── Arranque (disco completo, solo NixOS) ──────────────────────────────
  boot.loader = {
    systemd-boot = {
      enable = true;
      configurationLimit = 10;
    };
    efi.canTouchEfiVariables = true;
    timeout = 5;
  };
  # Kernel por defecto de nixpkgs (estable): evita problemas con el driver NVIDIA
  boot.kernelPackages = pkgs.linuxPackages;

  # ── Red, hora e idioma ─────────────────────────────────────────────────
  networking.hostName = "strix";
  time.timeZone = "Europe/Madrid";

  i18n = {
    defaultLocale = "es_ES.UTF-8";
    supportedLocales = [ "es_ES.UTF-8/UTF-8" "en_US.UTF-8/UTF-8" ];
  };
  console.keyMap = "es";
  services.xserver.xkb.layout = "es";

  # ── Usuario ────────────────────────────────────────────────────────────
  users.users.pepe = {
    isNormalUser = true;
    description = "José Ortiz Roldán";
    extraGroups = [ "wheel" "networkmanager" "video" "audio" "input" "docker" ];
    shell = pkgs.zsh;
    initialPassword = "cambiame"; # cámbiala con `passwd` en el primer arranque
  };
  programs.zsh.enable = true;

  # ── Nix: flakes, caché y limpieza automática del store ─────────────────
  nix = {
    settings = {
      experimental-features = [ "nix-command" "flakes" ];
      auto-optimise-store = true;   # deduplica ficheros idénticos
      trusted-users = [ "root" "pepe" ];
      max-jobs = "auto";
      cores = 0;
    };
    gc = {
      automatic = true;
      dates = "weekly";
      persistent = true;
      options = "--delete-older-than 14d";
    };
    optimise.automatic = true;
  };

  # ── Herramientas de desarrollo del sistema ─────────────────────────────
  virtualisation.docker = {
    enable = true;                  # `supabase start` necesita Docker
    enableOnBoot = false;           # arranca bajo demanda (ahorra RAM)
  };
  programs.nix-ld.enable = true;    # binarios precompilados (npm, Expo, extensiones de VS Code)

  environment.systemPackages = with pkgs; [
    git
    curl
    wget
    unzip
    htop
    pciutils
    usbutils
    asusctl
    android-tools # adb para Expo/Android por USB
  ];

  # Actualizaciones de firmware (BIOS/SSD) vía fwupd
  services.fwupd.enable = true;

  system.stateVersion = "26.05";
}
