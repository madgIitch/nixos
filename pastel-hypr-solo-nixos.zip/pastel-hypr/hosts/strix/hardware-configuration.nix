# Disco completo (solo NixOS). Montajes por ETIQUETA, como se crearon al instalar:
#   nixos → partición raíz ext4
#   BOOT  → partición EFI (FAT32, 1 GB) montada en /boot
# Si prefieres el archivo autogenerado, sustitúyelo por:
#   sudo nixos-generate-config --show-hardware-config > hosts/strix/hardware-configuration.nix
{ lib, modulesPath, ... }:
{
  imports = [ (modulesPath + "/installer/scan/not-detected.nix") ];

  boot.initrd.availableKernelModules = [ "nvme" "xhci_pci" "ahci" "usbhid" "usb_storage" "sd_mod" ];
  boot.kernelModules = [ "kvm-amd" ];

  fileSystems."/" = {
    device = "/dev/disk/by-label/nixos";
    fsType = "ext4";
    options = [ "noatime" ];
  };

  fileSystems."/boot" = {
    device = "/dev/disk/by-label/BOOT";
    fsType = "vfat";
    options = [ "fmask=0077" "dmask=0077" ];
  };

  nixpkgs.hostPlatform = lib.mkDefault "x86_64-linux";
}
