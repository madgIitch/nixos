# ASUS ROG Strix G15 G513IC — Ryzen 7 4800H (Radeon integrada) + NVIDIA RTX 3050 Laptop (Ampere)
# 16 GB DDR4-3200 · Intel NVMe 512 GB · Wi-Fi/Bluetooth MediaTek MT7921 · pantalla 1920×1080 a 144 Hz
{ inputs, config, ... }:
let
  # Mismos IDs que el perfil g513im (misma placa). Compruébalos con:  lspci -D | grep -E "VGA|3D"
  amdPci = "0000:05:00.0";    # Radeon, conectada a la pantalla interna
  nvidiaPci = "0000:01:00.0"; # RTX 3050
in
{
  # Perfil del G513IM (Ryzen 4800H + NVIDIA Ampere): CPU AMD con amd-pstate,
  # PRIME offload con los IDs PCI de esta placa, ajustes de portátil y SSD
  # y límite de carga de la batería
  imports = [ inputs.nixos-hardware.nixosModules.asus-rog-strix-g513im ];

  # Firmware: Wi-Fi/BT MediaTek MT7921, microcódigo AMD
  hardware.enableRedistributableFirmware = true;

  hardware.graphics = {
    enable = true;
    enable32Bit = true;
  };

  hardware.nvidia = {
    open = true;                       # la RTX 3050 (Ampere) usa el módulo abierto
    modesetting.enable = true;
    package = config.boot.kernelPackages.nvidiaPackages.stable;
    powerManagement = {
      enable = true;
      finegrained = true;              # apaga la dGPU cuando no se usa (batería)
    };
    nvidiaSettings = false;
    # El perfil ya pone los IDs y el offload; `nvidia-offload programa` para usar la NVIDIA
  };

  # Batería al 80 % (para cargar al 100 % una vez: `charge-upto 100`)
  hardware.asus.battery.chargeUpto = 80;

  # Enlaces estables a cada GPU para que Hyprland renderice en la AMD
  # (la NVIDIA solo como secundaria, p. ej. para el HDMI)
  services.udev.extraRules = ''
    KERNEL=="card*", SUBSYSTEM=="drm", KERNELS=="${amdPci}", SYMLINK+="dri/amd-igpu"
    KERNEL=="card*", SUBSYSTEM=="drm", KERNELS=="${nvidiaPci}", SYMLINK+="dri/nvidia-dgpu"
  '';

  # Teclado retroiluminado, perfiles de ventilador y energía de ASUS (`asusctl`)
  services.asusd.enable = true;
  services.power-profiles-daemon.enable = true;

  # 16 GB de RAM: swap comprimida en memoria, sin partición de swap
  zramSwap = {
    enable = true;
    memoryPercent = 50;
  };
}
